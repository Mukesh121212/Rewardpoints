const purchaseData = {
    data : [
        {
            date : new Date(),
            purchaseAmount : 200
        },
        {
            date : new Date(),
            purchaseAmount : 300
        },
        {
            date : new Date('12/10/2020'),
            purchaseAmount : 120
        }
    ]
}

export default purchaseData;