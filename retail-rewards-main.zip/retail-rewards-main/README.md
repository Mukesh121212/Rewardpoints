# retail-rewards

# Run npm install command on root director
# Run npm start to run project
# you can able to add the new purchase transaction 
